<?php
session_start();
require('functions.php');
// database connection
$connect = mysqli_connect('localhost','root','','lbms');
if($connect){
    //echo("<script>alert('Connection Success')</script>");
}else{
    echo("<script>alert('Connection Failed')</script>");
}

$book_id = "";
$b_title = "";
$author_name = "";
$publisher_name = "";
$book_shelf = "";
$issued_by = "";
$issued_for = "";
$issued_date = "";

$query = "select * from issued_books";

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../bootstrap-5.0.2-dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../userMainWindow.css">
    <title>Issued Books List</title>
</head>

<body>

    <div class="container-fluid">
        <nav class="navbar navbar-expand-lg navbar-warning bg-secondary">
            <div class="container-fluid">
                <a class="navbar-brand" href="admin_dashboard.php"><img src="../icons_library_app/library_logo.jpg"
                        alt="logo"></a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                    data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                    aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        <li class="nav-item">
                            <a class="nav-link" href="admin_dashboard.php"><img style="width:40px;"
                                    src="../icons_library_app/arrow.png" alt="arrow-icon"></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="admin_dashboard.php"><img style="width:40px;"
                                    src="../icons_library_app/home-page.png" alt="home-icon"></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="logout.php"><img style="width:40px;"
                                    src="../icons_library_app/logout_icon.jpg" alt="logout-icon"></a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
        <div class="title-slide">
            <marquee behavior="" direction="">Library Book Management System DDCL</marquee>
        </div>

        <div class="middle-section">

            <div class="row">
                <div class="col-md-1"></div>
                <div class="col-md-10">
                    <form action="">
                        <h4 style="text-align:center;">Issued All Books List</h4>
                        <br>
                        <table class="table-bordered" width="100%" style="text-align:center;">
                            <tr>
                                <th>Book ID:</th>
                                <th>Book Title:</th>
                                <th>Author Name:</th>
                                <th>Publisher Name:</th>
                                <th>Book Shelf:</th>
                                <th>Issued By:</th>
                                <th>Issued For:</th>
                                <th>Issued Date:</th>

                            </tr>
                            <?php 
                                $query_run = mysqli_query($connect,$query);
                                while($row = mysqli_fetch_array($query_run)){
                                    $book_id = $row['book_id'];
                                    $b_title = $row['b_title'];
                                    $author_name = $row['author_name'];
                                    $publisher_name = $row['publisher_name'];
                                    $book_shelf = $row['b_shelf'];
                                    $issued_by = $row['issued_by'];
                                    $issued_for = $row['issued_for'];
                                    $issued_date = $row['issued_date'];
                                    
                                    ?>
                            <tr>
                                <td><?php echo $book_id; ?></td>
                                <td><?php echo $b_title; ?></td>
                                <td><?php echo $author_name; ?></td>
                                <td><?php echo $publisher_name; ?></td>
                                <td><?php echo $book_shelf; ?></td>
                                <td><?php echo $issued_by; ?></td>
                                <td><?php echo $issued_for; ?></td>
                                <td><?php echo $issued_date; ?></td>

                            </tr>
                            <?php
                            }
                            ?>
                        </table>
                    </form>
                </div>
                <div class="col-md-1"></div>
            </div>

        </div>
        <br><br>
        <footer>
            <div class="foot">
                <a href="#">
                    <h6>Copyright By LBMS</h6>
                </a>
            </div>
        </footer>


        <script src="bootstrap-5.0.2-dist/js/bootstrap.min.js"></script>
</body>

</html>