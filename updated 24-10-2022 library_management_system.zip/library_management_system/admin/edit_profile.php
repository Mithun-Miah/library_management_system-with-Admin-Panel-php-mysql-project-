<?php
// For Store data
session_start();

$id=$_SESSION['id'];

$msg=$name=$email=$admin_id="";

$connect = mysqli_connect('localhost', 'root', '', 'library_management');

if($connect){
    //echo "<script>alert('DB Connection Success')</script>";
}else{
    echo "<script>alert('DB Connection Failed')</script>";
}

$select = "SELECT * FROM admins where id='$id'";
$query = mysqli_query($connect,$select);

$row=mysqli_fetch_array($query);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../bootstrap-5.0.2-dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../passwordChange.css">
    <title>EDIT ADMIN PROFILE</title>
</head>
<body>
<div class="container-fluid">

<nav class="navbar navbar-expand-lg navbar-warning bg-secondary">
                <div class="container-fluid">
                    <a class="navbar-brand" href="admin_dashboard.php"><img src="../icons_library_app/library_logo.jpg" alt="logo"></a>
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="admin_dashboard.php"><img style="width:30px;" src="../icons_library_app/home-page.png" alt="home-icon"></a>
                        </li>
                        <li class="nav-item">
                        <a class="nav-link" href="logout.php"><img style="width:30px;" src="../icons_library_app/logout_icon.jpg" alt="logout-icon"></a>
                        </li>
                    </ul>

                    </div>
</nav>

        <div class="title-slide">
            <marquee behavior="" direction="">Library Book Management System DDCL</marquee>
        </div>
<br></br>
<div class="pass-changeForm" style="width:600px;margin:auto;border-radius:20px;box-shadow:2px 4px 6px black;border:2px solid green;padding:20px;text-align:center;">

<form action="update.php" method="POST">

    <h3 style="color:white;background-color:#10bccc;padding:8px;">Update Your Profile</h3>
    <input type="text" name="name" value="<?php echo $row['name']; ?>" placeholder="Name" style="width:80%;padding:8px;border-radius:8px;">
    <br><br>
    <input type="text" name="admin_id" value="<?php echo $row['admin_id']; ?>" placeholder="Admin Id" style="width:80%;padding:8px;border-radius:8px;">
    <br><br>
    <input type="email" name="email" value="<?php echo $row['email']; ?>" placeholder="Email" style="width:80%;padding:8px;border-radius:8px;">
    <br><br>
    
    <input type="submit" name="edit_Btn" id="edit_Btn" value="Update" style="width:80%;box-shadow:2px 4px 6px black;border:none;padding:8px;border-radius:8px;background-color:#258c06;color:white;font-size:1.3rem;font-weight:600;">

</form>

</div>
<br></br><br></br>
    <footer>
        <div class="foot">
            <a href="#"><h6>Copyright By LBMS</h6></a>
        </div>
    </footer>
</div>

<script src="bootstrap-5.0.2-dist/js/bootstrap.min.js"></script>
</body>
</html>

<?php
      if(isset($_POST['edit_Btn'])){
        $name = $_POST['name'];
        $admin_id = $_POST['admin_id'];
        $email = $_POST['email'];
      $query = "UPDATE admins SET name = '$name', admin_id = '$admin_id', email = $email,
                      WHERE id = '$id'";
                    $result = mysqli_query($connect, $query) or die(mysqli_error($db));
                    ?>
                     <script type="text/javascript">
            alert("Update Successful.");
            window.location = "edit_profile.php";
        </script>
        <?php
             }              
?>