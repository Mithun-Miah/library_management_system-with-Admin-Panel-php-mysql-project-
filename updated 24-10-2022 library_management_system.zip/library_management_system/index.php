<?php
// For Store data
session_start();

$connect = mysqli_connect('localhost', 'root', '', 'library_management');

if($connect){
    //echo "<script>alert('DB Connection Success')</script>";
}else{
    echo "<script>alert('DB Connection Failed')</script>";
}

$msg = "";

if(isset($_POST['login'])){
    $em_id = $_POST['em_id'];
    $password = $_POST['password'];

    $select = "SELECT * FROM user_register WHERE em_id = '$em_id' AND password = '$password'";
    $query = mysqli_query($connect,$select);
    $fetch = mysqli_fetch_array($query);

    if($fetch){
        // fetch email address from database to another page display
        $_SESSION['name'] = $fetch['name'];
        // fetch password from database to another page display
        $_SESSION['em_id'] = $fetch['em_id'];
        // fetch password from database to another page display
        $_SESSION['email'] = $fetch['email'];
        header("location: user_main_window.php");
    }elseif($em_id == "" ||$password==""){
        $msg = "Please Enter Your Id and Password !";
    }else{
        $msg = "Your Id and Password Not Match !";
        //echo "<script>alert('Login Failed')</script>";
        //header("location: index.php");        
    }

    }

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap-5.0.2-dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="index.css">
    <title>LBMS</title>
</head>
<body>

    <div class="container-fluid">
            <nav class="navbar navbar-expand-lg navbar-warning bg-secondary">
                <div class="container-fluid">
                    <a class="navbar-brand" href="#"><img src="icons_library_app/library_logo.jpg" alt="logo"></a>
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="register.php">Register</a>
                        </li>
                        <li class="nav-item">
                        <a class="nav-link" href="index.php">User Login</a>
                        </li>
                        <li class="nav-item">
                        <a class="nav-link" href="admin/index.php">Admin Login</a>
                        </li>
                    </ul>
                    </div>
                </div>
        </nav>
        <div class="title-slide">
            <marquee behavior="" direction="">Library Book Management System DDCL</marquee>
        </div>

        <div class="middle-section">
        
        <div class="left-side">
            <h5>*** Opening Time ***</h5>
            <p>From Morning 8:30AM </p>
            <h5>*** Closing Time ***</h5>
            <p>Evening 5:30PM </p>
        </div>

        <div class="right-side">
            <h5>User Login Here</h5>
            <p style="text-shadow: 1px 2px 2px black;color:red;padding:5px;text-align:center;font-weight:600;font-size:1.2rem;">
                <?php echo $msg; ?>
            </p>
            <form method="POST">
                <div class="mb-3">
                    <label for="exampleInputEmail1" class="form-label">Employee ID</label>
                    <input type="employeeId" name="em_id" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" require>
                    <!-- <div id="emailHelp" class="form-text">We'll never share your email with anyone else.</div> -->
                </div>
                <div class="mb-3">
                    <label for="exampleInputPassword1" class="form-label">Password</label>
                    <input type="password" name="password" class="form-control" id="exampleInputPassword1" require>
                </div>
                <button type="submit" name="login" class="btn btn-primary">Login</button>
                <a href="register.php">Click Here To Register ?</a>
            </form>
        </div>
        
        </div>

        <footer>
            <div class="foot">
                <a href="#"><h6>Copyright By LBMS</h6></a>
            </div>
        </footer>
        
    </div>


    <script src="bootstrap-5.0.2-dist/js/bootstrap.min.js"></script>
</body>
</html>