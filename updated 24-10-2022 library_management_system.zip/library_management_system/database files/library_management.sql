-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 01, 2022 at 08:24 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `library_management`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `admin_id` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `name`, `email`, `admin_id`, `password`) VALUES
(1, 'admin_master', 'admin001@gmail.com', 'A-01', '100'),
(2, 'admin02', 'admin02@gmail.com', 'A-02', '200');

-- --------------------------------------------------------

--
-- Table structure for table `authors`
--

CREATE TABLE `authors` (
  `author_id` int(11) NOT NULL,
  `author_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `authors`
--

INSERT INTO `authors` (`author_id`, `author_name`) VALUES
(1, 'UM SHAMSI'),
(2, 'JAMES H. BRUNS'),
(3, 'IRC'),
(4, 'ROBERT F. STEIDEL');

-- --------------------------------------------------------

--
-- Table structure for table `book_entry`
--

CREATE TABLE `book_entry` (
  `sl_no` int(11) NOT NULL,
  `book_id` varchar(100) NOT NULL,
  `b_title` varchar(1000) NOT NULL,
  `b_sub_title` varchar(1000) NOT NULL,
  `author_name` varchar(100) NOT NULL,
  `co_author` varchar(100) NOT NULL,
  `editor` varchar(100) NOT NULL,
  `category` varchar(300) NOT NULL,
  `sub_category` varchar(300) NOT NULL,
  `subject` varchar(1000) NOT NULL,
  `publisher_name` varchar(200) NOT NULL,
  `edition` varchar(100) NOT NULL,
  `isbn_no` varchar(100) NOT NULL,
  `copyright` varchar(100) NOT NULL,
  `book_location` varchar(100) NOT NULL,
  `shelf_no` varchar(100) NOT NULL,
  `entry_date_and_time` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `book_entry`
--

INSERT INTO `book_entry` (`sl_no`, `book_id`, `b_title`, `b_sub_title`, `author_name`, `co_author`, `editor`, `category`, `sub_category`, `subject`, `publisher_name`, `edition`, `isbn_no`, `copyright`, `book_location`, `shelf_no`, `entry_date_and_time`) VALUES
(2, 'A-01756', 'GREAT AMERICAN POST OFFICES', '', 'JAMES H. BRUNS', '', '', 'Architecture', 'Architecture', 'Post office buildings--United States', 'JOHN WILEY & SONS', '', '0-471-14388-X', '1998', 'DDC CENTER', 'GS-6/SS-41/S-1', '2022-04-06 11:50:26'),
(3, 'A-07204', 'A POLICY ON ROADSIDE ADVERTISEMENTS (FIRST REVISION) (IRC : 46-1972)', '', 'IRC', '', '', 'Engineering', 'Civil engineering', 'Policy on roadside advertisements', 'IRC', '', '', '', 'DDC CENTER', 'GS-4/SS-27/S-1', '2022-04-06 11:53:55'),
(4, 'A-16243', 'GIS APPLICATIONS FOR WATER, WASTEWATER, AND STORMWATER SYSTEMS', '', 'UM SHAMSI', '', '', 'Engineering', 'Environmental engineering', 'Water--Distribution', 'CRC PRESS', '', '0-8493-2097-2', '2005', 'DDC CENTER', 'GS-5/SS-33/S-3', '2022-04-06 11:58:16'),
(5, 'A-01471', 'AN INTRODUCTION TO MECHANICAL VIBRATIONS', '', 'ROBERT F. STEIDEL', '', '', 'Engineering', 'Applied Physics', 'Vibration', 'JOHN WILEY & SONS', '3rd', '0-471-84545-0', '1989', 'DDC CENTER', 'GS-6/SS-39/S-1', '2022-04-07 08:42:04');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `category_id` int(11) NOT NULL,
  `category_name` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`category_id`, `category_name`) VALUES
(1, 'Agriculture'),
(2, 'Architecture'),
(3, 'Biology'),
(4, 'Construction and Buildings'),
(5, 'Computer Science'),
(6, 'Engineering'),
(7, 'Physics'),
(8, 'Political Science'),
(9, 'Science'),
(10, 'Technology'),
(11, 'Economics'),
(12, 'Education');

-- --------------------------------------------------------

--
-- Table structure for table `issue_book`
--

CREATE TABLE `issue_book` (
  `id` int(11) NOT NULL,
  `book_id` varchar(100) NOT NULL,
  `b_title` varchar(1000) NOT NULL,
  `author_name` varchar(100) NOT NULL,
  `publisher_name` varchar(100) NOT NULL,
  `category` varchar(100) NOT NULL,
  `issued_by` varchar(50) NOT NULL,
  `issued_for` varchar(50) NOT NULL,
  `issue_date` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `issue_book`
--

INSERT INTO `issue_book` (`id`, `book_id`, `b_title`, `author_name`, `publisher_name`, `category`, `issued_by`, `issued_for`, `issue_date`) VALUES
(1, 'A-01756', 'GREAT AMERICAN POST OFFICES', 'JAMES H. BRUNS', 'JOHN WILEY & SONS', 'Architecture', 'Mithun', 'Hannan', ''),
(2, 'A-07204', 'A POLICY ON ROADSIDE ADVERTISEMENTS (FIRST REVISION) (IRC : 46-1972)', 'IRC', 'IRC', 'Engineering', 'Mithun', 'Hannan', 'issue_date'),
(3, 'A-16243', 'GIS APPLICATIONS FOR WATER, WASTEWATER, AND STORMWATER SYSTEMS', 'UM SHAMSI', 'CRC PRESS', 'Engineering', 'Raihan', 'Mithun', '06/04/2022'),
(4, 'A-01471', 'AN INTRODUCTION TO MECHANICAL VIBRATIONS', 'ROBERT F. STEIDEL', 'JOHN WILEY & SONS', 'Engineering', 'Nasir', 'Hannan', '07/04/2022');

-- --------------------------------------------------------

--
-- Table structure for table `publishers`
--

CREATE TABLE `publishers` (
  `publisher_id` int(11) NOT NULL,
  `publisher_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `publishers`
--

INSERT INTO `publishers` (`publisher_id`, `publisher_name`) VALUES
(1, 'JOHN WILEY & SONS'),
(2, 'CRC PRESS'),
(3, 'IRC'),
(4, 'JOHN WILEY & SONS');

-- --------------------------------------------------------

--
-- Table structure for table `user_register`
--

CREATE TABLE `user_register` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `dept_name` varchar(100) NOT NULL,
  `em_id` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `c_password` varchar(100) NOT NULL,
  `date_time` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user_register`
--

INSERT INTO `user_register` (`id`, `name`, `dept_name`, `em_id`, `email`, `password`, `c_password`, `date_time`) VALUES
(1, 'Test03', 'ddc library', '05-00003', 'test03@gmail.com', '111', '123', '2022-03-31 09:29:21'),
(3, 'Test03', 'Library', '05-00003', 'test03@gmail.com', '111', '456', '2022-03-31 10:02:28'),
(4, 'Test03', 'library', '05-00003', 'test03@gmail.com', '111', '789', '2022-03-31 10:34:44');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `authors`
--
ALTER TABLE `authors`
  ADD PRIMARY KEY (`author_id`);

--
-- Indexes for table `book_entry`
--
ALTER TABLE `book_entry`
  ADD PRIMARY KEY (`sl_no`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `issue_book`
--
ALTER TABLE `issue_book`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `publishers`
--
ALTER TABLE `publishers`
  ADD PRIMARY KEY (`publisher_id`);

--
-- Indexes for table `user_register`
--
ALTER TABLE `user_register`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `authors`
--
ALTER TABLE `authors`
  MODIFY `author_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `book_entry`
--
ALTER TABLE `book_entry`
  MODIFY `sl_no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `issue_book`
--
ALTER TABLE `issue_book`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `publishers`
--
ALTER TABLE `publishers`
  MODIFY `publisher_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `user_register`
--
ALTER TABLE `user_register`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
