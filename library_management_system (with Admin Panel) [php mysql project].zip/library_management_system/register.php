<?php
$connect = mysqli_connect('localhost','root','','lbms');

$msg=$name=$dept_name=$em_id=$email=$password=$c_password= "";

if($connect){
    //echo("<script>alert('Connection Success')</script>");
}else{
    echo("<script>alert('Connection Failed')</script>");
}

if(isset($_POST['reg_btn'])){
    $name = $_POST['full_name'];
    $dept_name = $_POST['dept_name'];
    $em_id = $_POST['em_id'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $c_password = $_POST['c_password'];

    // check duplicate email
    $emailandemid_check = "SELECT * FROM register_users where email = '$email' AND em_id = '$em_id'";
    // run query
    $email_query = mysqli_query($connect, $emailandemid_check); // Execute query
    // check number of rows
    $num_row = mysqli_num_rows($email_query);

    if($num_row>0){
        $msg = "email already exist, please try another email"; // show duplicate email user input
    }else{
        // check password and confirm password
        if($password==$c_password){
            $specialChars = preg_match('@[^\w]@', $password); // check password special charecter
            // check password special charecter and password length
            if(!$specialChars || strlen($password) == 4 || strlen($password) < 4){
                $msg = "***Please give a special character and password length more then 4***";

            } else{
                // data insert query working
                $insertData = "INSERT INTO register_users(full_name,dept_name,em_id,email,password,c_password) 
                VALUES('$name','$dept_name','$em_id','$email','$password','$c_password')";

                $query = mysqli_query($connect, $insertData);
                if($query){
                    $msg = "Registration Successful";
                    header('Location: index.php');
                } else{
                    $msg = "Registration Failed";
                    // header('Location: register.php');
                }

            }
        } else{
            echo ("<script>alert('Password and Confirm Password Dose Not Match !')</script>");
        }
    }
}


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap-5.0.2-dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="register.css">
    <title>LBMS</title>
</head>

<body>

    <div class="container-fluid">
        <nav class="navbar navbar-expand-lg navbar-warning bg-secondary">
            <div class="container-fluid">
                <a class="navbar-brand" href="#"><img src="icons_library_app/library_logo.jpg" alt="logo"></a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                    data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                    aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        <li class="nav-item">
                            <a class="nav-link active" aria-current="page" href="register.php">Register</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="index.php">User Login</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="admin/index.php">Admin Login</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
        <div class="title-slide">
            <marquee behavior="" direction="">Library Book Management System DDCL</marquee>
        </div>

        <h6 style="color:red; font-size:1rem; font-weight:600; padding:5px;text-align:center;"><?php echo $msg;?></h6>

        <div class="middle-section">

            <div class="left-side">
                <h5>*** Opening Time ***</h5>
                <p>From Morning 8:30AM </p>
                <h5>*** Closing Time ***</h5>
                <p>Evening 5:30PM </p>
            </div>

            <div class="right-side">
                <h5>User Registration</h5>

                <form method="POST">
                    <div class="mb-3">
                        <label for="exampleInputEmail1" class="form-label">Full Name</label>
                        <input type="name" name="full_name" value="<?php echo $name ?>" class="form-control"
                            id="exampleInputEmail1" aria-describedby="emailHelp" require>
                    </div>
                    <div class="mb-3">
                        <label for="exampleInputEmail1" class="form-label">Department Name</label>
                        <input type="name" name="dept_name" value="<?php echo $dept_name ?>" class="form-control"
                            id="exampleInputEmail1" aria-describedby="emailHelp" require>
                    </div>
                    <div class="mb-3">
                        <label for="exampleInputEmail1" class="form-label">Employee Id</label>
                        <input type="name" name="em_id" value="<?php echo $em_id ?>" class="form-control"
                            id="exampleInputEmail1" aria-describedby="emailHelp" require>
                    </div>
                    <div class="mb-3">
                        <label for="exampleInputEmail1" class="form-label">Email address</label>
                        <input type="email" name="email" value="<?php echo $email ?>" class="form-control"
                            id="exampleInputEmail1" aria-describedby="emailHelp" require>
                    </div>
                    <div class="mb-3">
                        <label for="exampleInputPassword1" class="form-label">Password</label>
                        <input type="password" name="password" value="<?php echo $password ?>" class="form-control"
                            id="exampleInputPassword1" require>
                    </div>
                    <div class="mb-3">
                        <label for="exampleInputPassword1" class="form-label">Confirm Password</label>
                        <input type="password" name="c_password" value="<?php echo $c_password ?>" class="form-control"
                            id="exampleInputPassword1" require>
                    </div>
                    <button type="submit" name="reg_btn" id="reg_btn" class="btn btn-primary">Register</button>
                </form>
            </div>

        </div>

        <footer>
            <div class="foot">
                <a href="#">
                    <h6>Copyright By LBMS</h6>
                </a>
            </div>
        </footer>

    </div>


    <script src="bootstrap-5.0.2-dist/js/bootstrap.min.js"></script>
</body>

</html>