-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 24, 2022 at 12:13 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `library_management`
--

-- --------------------------------------------------------

--
-- Table structure for table `book_entry`
--

CREATE TABLE `book_entry` (
  `sl_no` int(11) NOT NULL,
  `book_id` varchar(100) NOT NULL,
  `b_title` varchar(1000) NOT NULL,
  `b_sub_title` varchar(1000) NOT NULL,
  `author_name` varchar(100) NOT NULL,
  `co_author` varchar(100) NOT NULL,
  `editor` varchar(100) NOT NULL,
  `category` varchar(300) NOT NULL,
  `sub_category` varchar(300) NOT NULL,
  `subject` varchar(1000) NOT NULL,
  `publisher_name` varchar(200) NOT NULL,
  `edition` varchar(100) NOT NULL,
  `isbn_no` varchar(100) NOT NULL,
  `copyright` varchar(100) NOT NULL,
  `book_location` varchar(100) NOT NULL,
  `shelf_no` varchar(100) NOT NULL,
  `entry_date_and_time` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `book_entry`
--

INSERT INTO `book_entry` (`sl_no`, `book_id`, `b_title`, `b_sub_title`, `author_name`, `co_author`, `editor`, `category`, `sub_category`, `subject`, `publisher_name`, `edition`, `isbn_no`, `copyright`, `book_location`, `shelf_no`, `entry_date_and_time`) VALUES
(2, 'A-01756', 'GREAT AMERICAN POST OFFICES', '', 'JAMES H. BRUNS', '', '', 'Architecture', 'Architecture', 'Post office buildings--United States', 'JOHN WILEY & SONS', '', '0-471-14388-X', '1998', 'DDC CENTER', 'GS-6/SS-41/S-1', '2022-04-06 11:50:26'),
(3, 'A-07204', 'A POLICY ON ROADSIDE ADVERTISEMENTS (FIRST REVISION) (IRC : 46-1972)', '', 'IRC', '', '', 'Engineering', 'Civil engineering', 'Policy on roadside advertisements', 'IRC', '', '', '', 'DDC CENTER', 'GS-4/SS-27/S-1', '2022-04-06 11:53:55'),
(4, 'A-16243', 'GIS APPLICATIONS FOR WATER, WASTEWATER, AND STORMWATER SYSTEMS', '', 'UM SHAMSI', '', '', 'Engineering', 'Environmental engineering', 'Water--Distribution', 'CRC PRESS', '', '0-8493-2097-2', '2005', 'DDC CENTER', 'GS-5/SS-33/S-3', '2022-04-06 11:58:16'),
(5, 'A-01471', 'AN INTRODUCTION TO MECHANICAL VIBRATIONS', '', 'ROBERT F. STEIDEL', '', '', 'Engineering', 'Applied Physics', 'Vibration', 'JOHN WILEY & SONS', '3rd', '0-471-84545-0', '1989', 'DDC CENTER', 'GS-6/SS-39/S-1', '2022-04-07 08:42:04');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `book_entry`
--
ALTER TABLE `book_entry`
  ADD PRIMARY KEY (`sl_no`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `book_entry`
--
ALTER TABLE `book_entry`
  MODIFY `sl_no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
