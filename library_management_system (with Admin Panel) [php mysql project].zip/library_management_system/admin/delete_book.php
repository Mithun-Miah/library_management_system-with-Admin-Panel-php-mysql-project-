<?php

    // Database Connection with mysql database
    $connect = mysqli_connect("localhost", "root", "", "lbms");

    $book_id = $_GET['bn'];

    //For Show Data in Delete page input field
    $delete = "DELETE FROM books WHERE book_id = $book_id";
    $query = mysqli_query($connect, $delete);
    
    if($query){
        header("location:manage_book.php");
    } else{
        echo "<script>alert('Data Delete Fail')</script>";
    }

?>