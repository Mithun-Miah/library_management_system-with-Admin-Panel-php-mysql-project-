<?php
session_start();
require('functions.php');

// database connection
$connect = mysqli_connect('localhost','root','','lbms');

if($connect){
    //echo("<script>alert('Connection Success')</script>");
}else{
    echo("<script>alert('Connection Failed')</script>");
}

$author_id = "";
$author_name = "";

$query = "select * from authors";

if(isset($_POST['add_author'])){
    $author_id = $_POST['author_id'];
    $author_name = $_POST['author_name'];

    $insertData = "INSERT INTO authors(author_id,author_name) 
                VALUES('$author_id','$author_name')";

    $query_run = mysqli_query($connect,$insertData);

    if($query_run){
        echo("<script>alert('Author Add Successful')</script>");
        //header('Location: add_author.php');
    } else{
        echo("<script>alert('Author Add Failed')</script>");

    }

}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../bootstrap-5.0.2-dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../userMainWindow.css">
    <title>Add Author</title>
</head>

<body>

    <div class="container-fluid">
        <nav class="navbar navbar-expand-lg navbar-warning bg-secondary">
            <div class="container-fluid">
                <a class="navbar-brand" href="admin_dashboard.php"><img src="../icons_library_app/library_logo.jpg"
                        alt="logo"></a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                    data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                    aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        <li class="nav-item">
                            <a class="nav-link" href="author_item.php"><img style="width:40px;"
                                    src="../icons_library_app/arrow.png" alt="arrow-icon"></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="admin_dashboard.php"><img style="width:40px;"
                                    src="../icons_library_app/home-page.png" alt="home-icon"></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="logout.php"><img style="width:40px;"
                                    src="../icons_library_app/logout_icon.jpg" alt="logout-icon"></a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
        <div class="title-slide">
            <marquee behavior="" direction="">Library Book Management System DDCL</marquee>
        </div>

        <div class="middle-section">

            <div class="user-information">

                <div class="row w-100" style="display:flex;flex-wrap:nowrap;margin-top:25px;">

                    <div class="col-md-3"></div>

                    <div class="col-md-6" style="border:1px solid red;padding:20px;">
                        <h4 style="text-align:center;">Add New Author</h4>
                        <form action="" method="POST">
                            <div class="form-group">
                                <label for="">Author Id</label>
                                <input type="text" name="author_id" class="form-control" require>
                            </div>
                            <div class="form-group">
                                <label for="">Author Name</label>
                                <input type="text" name="author_name" class="form-control" require>
                            </div>

                            <br>
                            <button class="btn btn-primary" name="add_author">Add Author</button>
                        </form>
                        <br>
                        <h4 class="card-title">Total Authors: <?php echo get_author_count(); ?></h4>
                        <br>
                        <form action="">
                            <table class="table-bordered" width="100%" style="text-align:center;">
                                <tr>
                                    <th>Author ID:</th>
                                    <th>Author Name:</th>

                                </tr>
                                <?php 
                                $query_run = mysqli_query($connect,$query);
                                while($row = mysqli_fetch_array($query_run)){
                                    $author_id = $row['author_id'];
                                    $author_name = $row['author_name'];
                                    
                                    ?>
                                <tr>
                                    <td><?php echo $author_id; ?></td>
                                    <td><?php echo $author_name; ?></td>

                                </tr>
                                <?php
                            }
                            ?>
                            </table>
                        </form>
                    </div>

                    <div class="col-md-3"></div>

                </div>

            </div>

        </div>
        <br><br><br><br><br><br><br>
        <footer>
            <div class="foot">
                <a href="#">
                    <h6>Copyright By LBMS</h6>
                </a>
            </div>
        </footer>


        <script src="bootstrap-5.0.2-dist/js/bootstrap.min.js"></script>
</body>

</html>