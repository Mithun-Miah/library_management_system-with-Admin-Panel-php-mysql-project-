<?php
session_start();

// database connection
$connect = mysqli_connect('localhost','root','','lbms');

if($connect){
    //echo("<script>alert('Connection Success')</script>");
}else{
    echo("<script>alert('Connection Failed')</script>");
}

$getid = $_GET['id'];

$sql = "SELECT * FROM admins WHERE id = $getid";

$query = mysqli_query($connect,$sql);
$data = mysqli_fetch_array($query);

$user_id = $data['id'];
$user_name = $data['name'];
$dept_name = $data['dept'];
$email = $data['email'];

if(isset($_POST['name']) && isset($_POST['email']) && isset($_POST['dept']) && isset($_POST['id'])){
    $id = $_POST['id'];
	$name = $_POST['name'];
    $email = $_POST['email'];
    $dept = $_POST['dept'];
	
	$sql = "UPDATE admins SET name='$name', dept='$dept', email='$email' WHERE id=$id";

    if(mysqli_query($connect, $sql)){
		
		echo 'Data Updated';
		header('Location: admin_dashboard.php');
	}else{
		echo 'Data Updated Failed';
	}
    
} 

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../bootstrap-5.0.2-dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../userMainWindow.css">
    <title>Update Admin Profile</title>

    <style>
    .container {
        width: 500px;
        /* border: 1px solid black; */
        height: 400px;
        margin: 0px auto;
        text-align: center;
        padding: 10px;
    }

    h1 {
        background-color: blue;
        color: white;
        padding: 10px;
        text-align: center;
    }

    form input {
        border: 2px solid green;
        width: 90%;
        padding: 10px;
    }

    select {
        width: 90%;
        padding: 10px;
        border: 2px solid green;
    }

    button {
        padding: 10px;
        width: 90%;
        color: white;
        background-color: green;
        font-size: 18px;
        font-weight: 700;
        letter-spacing: 2px;
        border: none;
        cursor: pointer;
        transition: 0.2s ease-in;
    }

    button:hover {
        background-color: blue;
    }

    table,
    th,
    td {
        border: 1px solid black;
        border-collapse: collapse;
        padding: 3px;
    }

    .logoutDiv {
        margin-bottom: 20px;
        text-align: right;
    }

    .logout {
        text-decoration: none;
        background-color: red;
        color: white;
        padding: 10px;
        font-size: 1.2rem;
        border-radius: 5px;
        cursor: pointer;
        transition: 0.2s;
    }

    .logout:hover {
        background-color: brown;
        color: white;
    }

    .backBtn {
        text-decoration: none;
        background-color: blue;
        color: white;
        padding: 10px;
        font-size: 1.2rem;
        border-radius: 5px;
        cursor: pointer;
        transition: 0.2s;
    }

    .backBtn:hover {
        background-color: black;
        color: white;
    }
    </style>
</head>

<body>

    <div class="container-fluid">
        <nav class="navbar navbar-expand-lg navbar-warning bg-secondary">
            <div class="container-fluid">
                <a class="navbar-brand" href="admin_dashboard.php"><img src="../icons_library_app/library_logo.jpg"
                        alt="logo"></a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                    data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                    aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        <li class="nav-item">
                            <a class="nav-link" href="admin_dashboard.php"><img style="width:40px;"
                                    src="../icons_library_app/home-page.png" alt="home-icon"></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="logout.php"><img style="width:40px;"
                                    src="../icons_library_app/logout_icon.jpg" alt="logout-icon"></a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
        <div class="title-slide">
            <marquee behavior="" direction="">Library Book Management System DDCL</marquee>
        </div>

        <div class="middle-section" style="margin:auto;display:block;">

            <form action="update.php" method="post" style="width:500px;margin:auto;">
                <h3 style="text-align:center; color:blue; font-weight:700;">UPDATE ADMIN INFORMATION</h3>
                <input type="text" value="<?php echo $user_id; ?>" name="id" hidden> <br><br>
                <input type="text" value="<?php echo $user_name; ?>" name="name" placeholder="Name" require> <br><br>
                <input type="email" value="<?php echo $email; ?>" name="email" placeholder="Email" require>
                <br><br>
                <input type="text" value="<?php echo $dept_name; ?>" name="dept" placeholder="Department" require>
                <br><br>
                <!-- <input type="submit" value="Submit"> -->
                <button name="edit">Update Data</button>
                <br><br>
                <div class="form-group" style="font-size:20px;text-align:center;">
                    <a href="admin_dashboard.php" style="text-decoration:none;">Back Home</a>
                </div>
            </form>

        </div>

    </div>

    <footer>
        <div class="foot">
            <a href="#">
                <h6>Copyright By LBMS</h6>
            </a>
        </div>
    </footer>

    </div>


    <script src="bootstrap-5.0.2-dist/js/bootstrap.min.js"></script>
</body>

</html>