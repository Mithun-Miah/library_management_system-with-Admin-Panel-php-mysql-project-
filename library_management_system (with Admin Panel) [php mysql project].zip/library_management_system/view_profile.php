<?php
session_start();

// database connection
$connect = mysqli_connect('localhost','root','','lbms');

if($connect){
    //echo("<script>alert('Connection Success')</script>");
}else{
    echo("<script>alert('Connection Failed')</script>");
}

$name="";
$dept_name="";
$em_id="";
$email="";

$query = "select * from register_users where full_name = '$_SESSION[full_name]'";

$query_run = mysqli_query($connect,$query);

while($row = mysqli_fetch_assoc($query_run)){
    $name = "$row[full_name]";
    $dept_name = "$row[dept_name]";
    $em_id = "$row[em_id]";
    $email = "$row[email]";
}

    $read = "SELECT * FROM register_users";
    $query = mysqli_query($connect, $read);

    $row = mysqli_fetch_array($query);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap-5.0.2-dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="userMainWindow.css">
    <title>View User Profile</title>
</head>

<body>

    <div class="container-fluid">
        <nav class="navbar navbar-expand-lg navbar-warning bg-secondary">
            <div class="container-fluid">
                <a class="navbar-brand" href="userMainWindow.php"><img src="icons_library_app/library_logo.jpg"
                        alt="logo"></a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                    data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                    aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        <li class="nav-item">
                            <a class="nav-link" href="userMainWindow.php"><img style="width:40px;"
                                    src="icons_library_app/home-page.png" alt="home-icon"></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="logout.php"><img style="width:40px;"
                                    src="icons_library_app/logout_icon.jpg" alt="logout-icon"></a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
        <div class="title-slide">
            <marquee behavior="" direction="">Library Book Management System DDCL</marquee>
        </div>

        <div class="middle-section" style="margin:auto;display:block;">

            <form action="" style="width:500px;margin:auto;">
                <h3 style="text-align:center; color:green; font-weight:700;">USER INFORMATION</h3>
                <h5 style="text-align:center;"><img style="width:200px;" src="icons_library_app/user_icon.png"
                        alt="user-icon"></h5>
                <div class="form-group">
                    <label for="" style="text-shadow:none;color:black;font-size:1.3rem;font-weight:500;">Name</label>
                    <input type="text" class="form-control" value="<?php echo $name;?>" disabled>
                </div>
                <div class="form-group">
                    <label for="" style="text-shadow:none;color:black;font-size:1.3rem;font-weight:500;">Department
                        Name</label>
                    <input type="text" class="form-control" value="<?php echo $dept_name;?>" disabled>
                </div>
                <div class="form-group">
                    <label for="" style="text-shadow:none;color:black;font-size:1.3rem;font-weight:500;">Employee
                        Id</label>
                    <input type="text" class="form-control" value="<?php echo $em_id;?>" disabled>
                </div>
                <div class="form-group">
                    <label for="" style="text-shadow:none;color:black;font-size:1.3rem;font-weight:500;">Email</label>
                    <input type="email" class="form-control" value="<?php echo $email;?>" disabled>
                </div>
            </form>

        </div>

    </div>

    <footer>
        <div class="foot">
            <a href="#">
                <h6>Copyright By LBMS</h6>
            </a>
        </div>
    </footer>

    </div>


    <script src="bootstrap-5.0.2-dist/js/bootstrap.min.js"></script>
</body>

</html>