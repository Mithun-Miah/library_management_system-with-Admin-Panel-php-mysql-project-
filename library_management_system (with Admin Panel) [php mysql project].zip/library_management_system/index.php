<?php
// For Store data
session_start();
//database connection
$connect = mysqli_connect('localhost','root','','lbms');

$msg=$email=$password= "";

if($connect){
    //echo("<script>alert('Connection Success')</script>");
}else{
    echo("<script>alert('Connection Failed')</script>");
}

//Select html form name attribute
if(isset($_POST['login'])){
    $query = "select * from register_users where email = '$_POST[email]'";
    $query_run = mysqli_query($connect,$query);
    while($row = mysqli_fetch_array($query_run)){
        if($row['email'] == $_POST['email']){
            if($row['password'] == $_POST['password']){
                $_SESSION['full_name'] = $row['full_name'];
                $_SESSION['email'] = $row['email'];
                $_SESSION['em_id'] = $row['em_id'];
                header('Location: userMainWindow.php');
            }else{
                echo "<script>alert('Email and Password Not Matched')</script>";
            }
        }
    }
    // $email = $_POST['email'];
    // $password = $_POST['password'];

    // $select = "SELECT * FROM register_users where email = '$email' AND password = '$password' ";
    // $query = mysqli_query($connect, $select);

    // $fetch = mysqli_fetch_array($query);
    // if($fetch){
    //     echo "<script>alert('Login Successful')</script>";
    //     header('Location: userMainWindow.php');
    //     // fetch email address from database to another page display
    //     $_SESSION['full_name'] = $fetch['full_name'];
    //     $_SESSION['em_id'] = $fetch['em_id'];
    //     $_SESSION['em_id'] = $row['em_id'];

    // }else{
    //     echo "<script>alert('Email and Password Not Matched')</script>";
    // }
}


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap-5.0.2-dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="index.css">
    <title>LBMS</title>
</head>

<body>

    <div class="container-fluid">
        <nav class="navbar navbar-expand-lg navbar-warning bg-secondary">
            <div class="container-fluid">
                <a class="navbar-brand" href="#"><img src="icons_library_app/library_logo.jpg" alt="logo"></a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                    data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                    aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        <li class="nav-item">
                            <a class="nav-link active" aria-current="page" href="register.php">Register</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="index.php">User Login</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="admin/index.php">Admin Login</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
        <div class="title-slide">
            <marquee behavior="" direction="">Library Book Management System DDCL</marquee>
        </div>

        <div class="middle-section">

            <div class="left-side">
                <h5>*** Opening Time ***</h5>
                <p>From Morning 8:30AM </p>
                <h5>*** Closing Time ***</h5>
                <p>Evening 5:30PM </p>
            </div>

            <div class="right-side">
                <h5>User Login Here</h5>
                <form method="POST">
                    <div class="mb-3">
                        <label for="exampleInputEmail1" class="form-label">Email address</label>
                        <input type="email" name="email" class="form-control" id="exampleInputEmail1"
                            aria-describedby="emailHelp" require>
                        <!-- <div id="emailHelp" class="form-text">We'll never share your email with anyone else.</div> -->
                    </div>
                    <div class="mb-3">
                        <label for="exampleInputPassword1" class="form-label">Password</label>
                        <input type="password" name="password" class="form-control" id="exampleInputPassword1" require>
                    </div>
                    <button type="submit" name="login" class="btn btn-primary">Login</button>
                </form>
            </div>

        </div>

        <footer>
            <div class="foot">
                <a href="#">
                    <h6>Copyright By LBMS</h6>
                </a>
            </div>
        </footer>

    </div>


    <script src="bootstrap-5.0.2-dist/js/bootstrap.min.js"></script>
</body>

</html>