<?php

    // Database Connection with mysql database
    $connect = mysqli_connect("localhost", "root", "", "lbms");

    $author_id = $_GET['an'];

    //For Show Data in Delete page input field
    $delete = "DELETE FROM authors WHERE author_id = $author_id";
    $query = mysqli_query($connect, $delete);
    
    if($query){
        header("location:manage_author.php");
    } else{
        echo "<script>alert('Data Delete Fail')</script>";
    }

?>