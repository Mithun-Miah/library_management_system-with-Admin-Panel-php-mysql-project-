<?php
session_start();
require('functions.php');

// database connection
$connect = mysqli_connect('localhost','root','','lbms');

if($connect){
    //echo("<script>alert('Connection Success')</script>");
}else{
    echo("<script>alert('Connection Failed')</script>");
}


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../bootstrap-5.0.2-dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../userMainWindow.css">
    <title>Manage Publisher</title>

    <style>
    .middle-section {
        height: auto;
    }
    </style>
</head>

<body>

    <div class="container-fluid">
        <nav class="navbar navbar-expand-lg navbar-warning bg-secondary">
            <div class="container-fluid">
                <a class="navbar-brand" href="admin_dashboard.php"><img src="../icons_library_app/library_logo.jpg"
                        alt="logo"></a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                    data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                    aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        <li class="nav-item">
                            <a class="nav-link" href="publisher_item.php"><img style="width:40px;"
                                    src="../icons_library_app/arrow.png" alt="arrow-icon"></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="admin_dashboard.php"><img style="width:40px;"
                                    src="../icons_library_app/home-page.png" alt="home-icon"></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="logout.php"><img style="width:40px;"
                                    src="../icons_library_app/logout_icon.jpg" alt="logout-icon"></a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
        <div class="title-slide">
            <marquee behavior="" direction="">Library Book Management System DDCL</marquee>
        </div>

        <div class="middle-section">

            <div class="user-information">

                <div class="row w-100" style="margin-top:25px;">
                    <div class="col-md-1"></div>
                    <div class="col-md-10" style="text-align:center;border:1px solid red;padding:10px;">
                        <h3>Manage Book Publisher</h3>
                        <table class="table table-bordered table-hover">
                            <thead>
                                <tr>
                                    <th>Publisher Id</th>
                                    <th>Publisher Name</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <?php
                                $query = "select * from publishers";
                                $query_run = mysqli_query($connect,$query);
                                while($row = mysqli_fetch_array($query_run)){
                                    $pub_id = $row['pub_id'];
                                    $pub_name = $row['pub_name'];
                                    
                                    ?>
                            <tr>
                                <td><?php echo $pub_id; ?></td>
                                <td><?php echo $pub_name; ?></td>
                                <td>
                                    <button class="btn" name=""><a
                                            href="edit_publisher.php?pn=<?php echo $row['pub_id']; ?>">Edit</a></button>
                                    <button class="btn" name=""><a onclick="return confirm('Do You Want To Delete !')"
                                            href="delete_publisher.php?pn=<?php echo $row['pub_id']; ?>">Delete</a></button>
                                </td>

                            </tr>
                            <?php
                            }
                            ?>

                        </table>
                    </div>

                    <div class="col-md-1"></div>

                </div>

            </div>

        </div>
        <br><br><br><br><br><br><br>
        <footer>
            <div class="foot">
                <a href="#">
                    <h6>Copyright By LBMS</h6>
                </a>
            </div>
        </footer>


        <script src="bootstrap-5.0.2-dist/js/bootstrap.min.js"></script>
</body>

</html>