<?php
session_start();
require('functions.php');

// database connection
$connect = mysqli_connect('localhost','root','','lbms');

if($connect){
    //echo("<script>alert('Connection Success')</script>");
}else{
    echo("<script>alert('Connection Failed')</script>");
}

if(isset($_POST['issue_book'])){
    $book_id = $_POST['book_id'];
    $b_title = $_POST['b_title'];
    $book_author = $_POST['book_author'];
    $book_publisher = $_POST['book_publisher'];
    $book_location = $_POST['book_location'];
    $b_shelf = $_POST['b_shelf'];
    $issue_by = $_POST['issue_by'];
    $issue_for = $_POST['issue_for'];
    $issue_date = $_POST['issue_date'];

    // data insert query working
    $insertData = "INSERT INTO issued_books(book_id,b_title,author_name,publisher_name,book_location,b_shelf,issued_by,issued_for,issued_date) 
    VALUES('$book_id','$b_title','$book_author','$book_publisher','$book_location','$b_shelf','$issue_by','$issue_for','$issue_date')";

    $query = mysqli_query($connect, $insertData);
    if($query){
        echo("<script>alert('Book Issued Successful')</script>");
        //header('Location: index.php');
    } else{
        echo("<script>alert('Book Issued Failed')</script>");
        // header('Location: register.php');
    }
}


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../bootstrap-5.0.2-dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../userMainWindow.css">
    <title>Issue Books</title>
</head>

<body>

    <div class="container-fluid">
        <nav class="navbar navbar-expand-lg navbar-warning bg-secondary">
            <div class="container-fluid">
                <a class="navbar-brand" href="admin_dashboard.php"><img src="../icons_library_app/library_logo.jpg"
                        alt="logo"></a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                    data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                    aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        <li class="nav-item">
                            <a class="nav-link" href="admin_dashboard.php"><img style="width:40px;"
                                    src="../icons_library_app/arrow.png" alt="arrow-icon"></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="admin_dashboard.php"><img style="width:40px;"
                                    src="../icons_library_app/home-page.png" alt="home-icon"></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="logout.php"><img style="width:40px;"
                                    src="../icons_library_app/logout_icon.jpg" alt="logout-icon"></a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
        <div class="title-slide">
            <marquee behavior="" direction="">Library Book Management System DDCL</marquee>
        </div>

        <div class="middle-section">

            <div class="user-information">

                <div class="row w-100" style="display:flex;flex-wrap:nowrap;margin-top:25px;">

                    <div class="col-md-3"></div>

                    <div class="col-md-6" style="border:1px solid red;padding:20px;">
                        <h4 style="text-align:center;">Book Issue</h4>
                        <form action="" method="POST">
                            <div class="form-group">
                                <label for="">Book Id</label>
                                <input type="text" name="book_id" class="form-control" require>
                            </div>
                            <div class="form-group">
                                <label for="">Book Title</label>
                                <input type="text" name="b_title" class="form-control" require>
                            </div>
                            <div class="form-group">
                                <label for="">Author</label>
                                <input type="text" name="book_author" class="form-control" require>
                                <!-- <select name="book_author" class="form-control" id="" require>
                                    <option value="">Select Author</option>
                                    <?php
                                        // database connection
                                        $connect = mysqli_connect('localhost','root','','lbms');
                                        $query = "select author_name from authors";
                                        $query_run = mysqli_query($connect,$query);
                                        while($row = mysqli_fetch_array($query_run)){ ?>
                                    <option value=""><?php echo $row['author_name']; ?></option>
                                    <?php    
                                        }
                                    ?>
                                </select> -->
                            </div>
                            <div class="form-group">
                                <label for="">Publisher</label>
                                <input type="text" name="book_publisher" class="form-control" require>
                            </div>

                            <div class="form-group">
                                <label for="">Book Location</label>
                                <!-- <input type="text" name="b_location" class="form-control" require> -->
                                <select name="book_location" class="form-control" id="">
                                    <option value="">-Select Book Location-</option>
                                    <option value="DDC Center">DDC Center</option>
                                    <option value="Matikata">Matikata</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="">Book Shelf</label>
                                <input type="text" name="b_shelf" class="form-control" require>
                            </div>
                            <div class="form-group">
                                <label for="">Issued By</label>
                                <input type="text" name="issue_by" class="form-control" require>
                            </div>
                            <div class="form-group">
                                <label for="">Issued For (Employee Id)</label>
                                <input type="text" name="issue_for" class="form-control" require>
                            </div>
                            <div class="form-group">
                                <label for="">Issued Date</label>
                                <input type="text" name="issue_date" class="form-control"
                                    value="<?php echo date("jS F Y"); ?>" require>
                            </div>
                            <br>
                            <button class="btn btn-primary" name="issue_book">Issued Book</button>
                        </form>
                    </div>

                    <div class="col-md-3"></div>

                </div>

            </div>

        </div>
        <br><br><br><br><br><br><br>
        <footer>
            <div class="foot">
                <a href="#">
                    <h6>Copyright By LBMS</h6>
                </a>
            </div>
        </footer>


        <script src="bootstrap-5.0.2-dist/js/bootstrap.min.js"></script>
</body>

</html>