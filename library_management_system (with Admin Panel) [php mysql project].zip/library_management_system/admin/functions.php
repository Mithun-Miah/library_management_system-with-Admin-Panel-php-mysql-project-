<?php
    function get_user_count(){
        // database connection
        $connect = mysqli_connect('localhost','root','','lbms');
        if($connect){
            //echo("<script>alert('Connection Success')</script>");
        }else{
            echo("<script>alert('Connection Failed')</script>");
        }
        $user_count = "";
        $query = "select count(*) as user_count from register_users";
        $query_run = mysqli_query($connect,$query);
        while($row = mysqli_fetch_array($query_run)){
            $user_count = $row['user_count'];
        }
        return($user_count);
    }

    function get_book_count(){
        // database connection
        $connect = mysqli_connect('localhost','root','','lbms');
        if($connect){
            //echo("<script>alert('Connection Success')</script>");
        }else{
            echo("<script>alert('Connection Failed')</script>");
        }
        $book_count = "";
        $query = "select count(*) as book_count from books";
        $query_run = mysqli_query($connect,$query);
        while($row = mysqli_fetch_array($query_run)){
            $book_count = $row['book_count'];
        }
        return($book_count);
    }

    function get_category_count(){
        // database connection
        $connect = mysqli_connect('localhost','root','','lbms');
        if($connect){
            //echo("<script>alert('Connection Success')</script>");
        }else{
            echo("<script>alert('Connection Failed')</script>");
        }
        $cat_count = "";
        $query = "select count(*) as cat_count from category";
        $query_run = mysqli_query($connect,$query);
        while($row = mysqli_fetch_array($query_run)){
            $cat_count = $row['cat_count'];
        }
        return($cat_count);
    }

    function get_author_count(){
        // database connection
        $connect = mysqli_connect('localhost','root','','lbms');
        if($connect){
            //echo("<script>alert('Connection Success')</script>");
        }else{
            echo("<script>alert('Connection Failed')</script>");
        }
        $auth_count = "";
        $query = "select count(*) as auth_count from authors";
        $query_run = mysqli_query($connect,$query);
        while($row = mysqli_fetch_array($query_run)){
            $auth_count = $row['auth_count'];
        }
        return($auth_count);
    }

    function get_publisher_count(){
        // database connection
        $connect = mysqli_connect('localhost','root','','lbms');
        if($connect){
            //echo("<script>alert('Connection Success')</script>");
        }else{
            echo("<script>alert('Connection Failed')</script>");
        }
        $pub_count = "";
        $query = "select count(*) as pub_count from publishers";
        $query_run = mysqli_query($connect,$query);
        while($row = mysqli_fetch_array($query_run)){
            $pub_count = $row['pub_count'];
        }
        return($pub_count);
    }

    function get_issued_book_count(){
        // database connection
        $connect = mysqli_connect('localhost','root','','lbms');
        if($connect){
            //echo("<script>alert('Connection Success')</script>");
        }else{
            echo("<script>alert('Connection Failed')</script>");
        }
        $issued_book_count = "";
        $query = "select count(*) as issued_book_count from issued_books";
        $query_run = mysqli_query($connect,$query);
        while($row = mysqli_fetch_array($query_run)){
            $issued_book_count = $row['issued_book_count'];
        }
        return($issued_book_count);
    }


?>