<?php
// For Store data
session_start();

$msg=$name= "";

$connect = mysqli_connect('localhost', 'root', '', 'library_management');

if($connect){
    //echo "<script>alert('DB Connection Success')</script>";
}else{
    echo "<script>alert('DB Connection Failed')</script>";
}

// For Secure URL / do not permission enter by url type
if($_SESSION['name'] == true){
    // after login fetch email address and password display from database into this page
    $msg = "Welcome : $_SESSION[name]";
    // $msg2 = "Employee ID : $_SESSION[em_id]";
    // $msg3 = "Email : $_SESSION[email]";
} else{
    header('Location: index.php');
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap-5.0.2-dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="user_main_window.css">
    <title>LBMS | HOME</title>
</head>
<body>

<div class="container-fluid">
<nav class="navbar navbar-expand-lg navbar-warning bg-secondary">
                <div class="container-fluid">
                    <a class="navbar-brand" href="#"><img src="icons_library_app/library_logo.jpg" alt="logo"></a>
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="user_main_window.php"><img style="width:30px;" src="icons_library_app/home-page.png" alt="home-icon"></a>
                        </li>
                        <li class="nav-item">
                        <a class="nav-link" href="logout.php"><img style="width:30px;" src="icons_library_app/logout_icon.jpg" alt="logout-icon"></a>
                        </li>
                    </ul>
                    </div>
</nav>

<div class="title-slide">
            <marquee behavior="" direction="">Library Book Management System DDCL</marquee>
        </div>

                    <div class="middle-section">
                        <div class="company-info" style="display:flex; justify-content:center; align-items:center;">
                            <img style="width:120px;" src="icons_library_app/library_logo.jpg" alt="company_logo">
                            <article style="background-color:yellow;padding:10px;">
                                <h4>DEVELOPMENT DESIGN CONSULTANTS LTD.</h4>
                                <h5>"DDC Center", 47 Mohakhali C/A, Dhaka-1212, Bangladesh"</h5>
                                <marquee behavior="" direction="">For Support Please Call +88 01911601021 , +88 01966167016 | You Have To Archive The Daily Backups In a Secondary Storage ( Like Pen Drive or External HDD ) And Keep In a Safe Place.
                                </marquee>
                            </article>
                        </div>
                        <br>
                        <p style="text-shadow: 1px 2px 2px black;color:green;padding:5px;text-align:center;font-weight:600;font-size:1.5rem;">
                            <?php echo $msg; ?>
                        </p>
                    <div class="work-section" style="display:flex;justify-content:center;align-items:center;gap: 50px;">

                        <a href="userProfile.php" style="text-decoration:none;color:orange;">
                            <img style="width:150px;" src="icons_library_app/profile_icon.png" alt="user-profile-icon">
                            <h5 style="text-align:center;">Profile</h5>
                        </a>

                        <a href="userProfileUpdate.php" style="text-decoration:none;color:orange;">
                            <img style="width:150px;" src="icons_library_app/user_update.png" alt="user-profile-update-icon">
                            <h5 style="text-align:center;">Update Profile</h5>
                        </a>

                        <a href="entryMenu.php" style="text-decoration:none;color:orange;">
                            <img style="width:150px;" src="icons_library_app/book.jpg" alt="book-icon">
                            <h5 style="text-align:center;">Entry Menu</h5>
                        </a>

                        <a href="passwordChange.php" style="text-decoration:none;color:orange;">
                            <img style="width:150px;" src="icons_library_app/key.png" alt="key-icon">
                            <h5 style="text-align:center;">Change Password</h5>
                        </a>
                    
                    </div>
                    <br><br><br><br><br>
    <footer>
            <div class="foot">
                <a href="#"><h6>Copyright By LBMS</h6></a>
            </div>
        </footer>
</div>    

    <script src="bootstrap-5.0.2-dist/js/bootstrap.min.js"></script>
</body>
</html>