<?php
// For Store data
session_start();

$connect = mysqli_connect('localhost', 'root', '', 'library_management');

if($connect){
    //echo "<script>alert('DB Connection Success')</script>";
}else{
    echo "<script>alert('DB Connection Failed')</script>";
}

if(isset($_POST['submit'])){
    $book_id = $_POST['book_id'];
    $b_title = $_POST['b_title'];
    $author_name = $_POST['author_name'];
    $publisher_name = $_POST['publisher_name'];
    $category = $_POST['category'];
    $issued_by = $_POST['issued_by'];
    $issued_for = $_POST['issued_for'];
    $issue_date = $_POST['issue_date'];

    if($book_id == "" || $issued_by == "" || $issued_for == "" || $issue_date == ""){
        echo "<script>alert('Must Entry Book Id, Issued By, Issued For and issue date Fields Correctly')</script>";
    }else{

        $insert = "INSERT INTO issue_book(book_id,b_title,author_name,publisher_name,category,issued_by,issued_for,issue_date)
                 VALUES ('$book_id','$b_title','$author_name','$publisher_name','$category','$issued_by','$issued_for','$issue_date')";
        
            $insert_query = mysqli_query($connect,$insert);
        
            if($insert_query){
                echo "<script>alert('Book Issued Successful')</script>";
                //header("location: add_book.php");
            }else{
                echo "<script>alert('Book Issued Unsuccessful')</script>";
            }

    }
                
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../bootstrap-5.0.2-dist/css/bootstrap.min.css">
    <!-- <link rel="stylesheet" href="user_main_window.css"> -->
    <title>Issue Book</title>

    <style>
                /* navbar css start */
        #navbarSupportedContent {
            text-align: right !important;
            display: inline !important;
            margin-left: 700px;
            width: 300px;
        }
        .navbar-brand img{
            width: 40px;
            height: 50px;
        }
        .nav-link {
            color: white !important;
        }
        .nav-link:hover {
            color: chartreuse !important;
        }
        /* navbar css end */
        /* title section css start */
        .title-slide{
            border-left: 4px solid red;
            border-right: 4px solid red;
        }
        /* title section css end */
        /*company-info section css start*/


        /*company-info section css end*/

        /* Footer section css start */
        .foot{
            background-color: rgb(71, 70, 70);
            color: white;
            padding: 10px;
            text-align: center;
        }
        .foot a{
            text-decoration: none;
        }
        .foot a:hover{
            color: orange;
        }

        /* Footer section css end */
    </style>
</head>
<body>

<div class="container-fluid">
<nav class="navbar navbar-expand-lg navbar-warning bg-secondary">
                <div class="container-fluid">
                    <a class="navbar-brand" href="admin_dashboard.php"><img src="../icons_library_app/library_logo.jpg" alt="logo"></a>
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="admin_dashboard.php"><img style="width:30px;" src="../icons_library_app/home-page.png" alt="home-icon"></a>
                        </li>
                        <li class="nav-item">
                        <a class="nav-link" href="logout.php"><img style="width:30px;" src="../icons_library_app/logout_icon.jpg" alt="logout-icon"></a>
                        </li>
                    </ul>
                    </div>
</nav>

                    <div class="title-slide">
                            <marquee behavior="" direction="">Library Book Management System DDCL</marquee>
                    </div>

                    <div class="work-section" style="margin:auto;border:1px solid red;padding:10px;">
                        <h4 style="text-align:center;">Book Issue</h4>

                        <form action="" method="post" style="margin:auto;padding:10px;width:60%;border:1px solid green;">
                            <label for="" style="text-align:left;">Book ID</label>
                            <br>
                            <input type="text" name="book_id" style="width:100%;">
                            <label for="" style="text-align:left;">Book Title</label>
                            <br>
                            <input type="text" name="b_title" style="width:100%;">
                            <label for="" style="text-align:left;">Author Name</label>
                            <br>
                            <input type="text" name="author_name" style="width:100%;">
                            <label for="" style="text-align:left;">Publisher Name</label>
                            <br>
                            <input type="text" name="publisher_name" style="width:100%;">
                            <label for="" style="text-align:left;">Category</label>
                            <br>
                            <input type="text" name="category" style="width:100%;">
                            <label for="" style="text-align:left;">Issued By</label>
                            <br>
                            <input type="text" name="issued_by" style="width:100%;">
                            <label for="" style="text-align:left;">Issued For</label>
                            <br>
                            <input type="text" name="issued_for" style="width:100%;">
                            <label for="" style="text-align:left;">Issue Date</label>
                            <br>
                            <input type="text" name="issue_date" value="<?php echo date("d/m/Y"); ?>" style="width:100%;">
                            <br><br>
                            <!-- <input type="button" name="submit" value="Submit" style="width:100%;background-color:green;color:white;font-size:1.3rem;font-weight:700;border:none;box-shadow:2px 2px 2px black;"> -->
                            <button name="submit" style="width:100%;background-color:green;color:white;font-size:1.3rem;font-weight:700;border:none;box-shadow:2px 2px 2px black;">Submit</button>
                        </form>
                        

                    </div>
                    
                    <br><br><br><br><br>
    <footer>
            <div class="foot">
                <a href="#"><h6>Copyright By LBMS</h6></a>
            </div>
        </footer>
</div>    

    <script src="bootstrap-5.0.2-dist/js/bootstrap.min.js"></script>
</body>
</html>