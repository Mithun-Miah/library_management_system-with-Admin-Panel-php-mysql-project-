<?php

    // Database Connection with mysql database
    $connect = mysqli_connect("localhost", "root", "", "lbms");

    $cat_id = $_GET['cn'];

    //For Show Data in Delete page input field
    $delete = "DELETE FROM category WHERE cat_id = $cat_id";
    $query = mysqli_query($connect, $delete);
    
    if($query){
        header("location:manage_cat.php");
    } else{
        echo "<script>alert('Data Delete Fail')</script>";
    }

?>