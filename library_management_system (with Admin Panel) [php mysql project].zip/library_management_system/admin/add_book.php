<?php
session_start();
require('functions.php');

// database connection
$connect = mysqli_connect('localhost','root','','lbms');

$msg= "";

if($connect){
    //echo("<script>alert('Connection Success')</script>");
}else{
    echo("<script>alert('Connection Failed')</script>");
}

if(isset($_POST['add_book'])){
    $name = $_POST['b_title'];
    $author_id = $_POST['author_id'];
    $category = $_POST['category'];
    $sub_category = $_POST['sub_category'];
    $publisher_id = $_POST['publisher_id'];
    $book_location = $_POST['book_location'];
    $b_shelf = $_POST['b_shelf'];

    $insertData = "INSERT INTO books(b_title,author_id,category,sub_category,publisher_id,b_location,b_shelf) 
                VALUES('$name','$author_id','$category','$sub_category','$publisher_id','$book_location','$b_shelf')";

    $query_run = mysqli_query($connect,$insertData);

    if($query_run){
        echo("<script>alert('Book Add Successful')</script>");
        $msg = "Book Add Successful";
        header('Location: add_book.php');
    } else{
        echo("<script>alert('Book Add Failed')</script>");

    }

}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../bootstrap-5.0.2-dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../userMainWindow.css">
    <title>Add Books</title>
</head>

<body>

    <div class="container-fluid">
        <nav class="navbar navbar-expand-lg navbar-warning bg-secondary">
            <div class="container-fluid">
                <a class="navbar-brand" href="admin_dashboard.php"><img src="../icons_library_app/library_logo.jpg"
                        alt="logo"></a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                    data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                    aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        <li class="nav-item">
                            <a class="nav-link" href="books_item.php"><img style="width:40px;"
                                    src="../icons_library_app/arrow.png" alt="arrow-icon"></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="admin_dashboard.php"><img style="width:40px;"
                                    src="../icons_library_app/home-page.png" alt="home-icon"></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="logout.php"><img style="width:40px;"
                                    src="../icons_library_app/logout_icon.jpg" alt="logout-icon"></a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
        <div class="title-slide">
            <marquee behavior="" direction="">Library Book Management System DDCL</marquee>
        </div>

        <div class="middle-section">

            <div class="user-information">

                <div class="row w-100" style="display:flex;flex-wrap:nowrap;margin-top:25px;">

                    <div class="col-md-3"></div>

                    <div class="col-md-6" style="border:1px solid red;padding:20px;">
                        <h4 style="text-align:center;">Add New Book</h4>
                        <h6 style="color:red; font-size:1rem; font-weight:600; padding:5px;text-align:center;">
                            <?php echo $msg;?></h6>
                        <form action="" method="POST">
                            <div class="form-group">
                                <label for="">Book Id</label>
                                <input type="text" name="book_id" class="form-control" require disabled>
                            </div>
                            <div class="form-group">
                                <label for="">Book Title</label>
                                <input type="text" name="b_title" class="form-control" require>
                            </div>
                            <div class="form-group">
                                <label for="">Author ID</label>
                                <input type="text" name="author_id" class="form-control" require>

                            </div>
                            <div class="form-group">
                                <label for="">Category</label>
                                <input type="text" name="category" class="form-control" require>
                            </div>
                            <div class="form-group">
                                <label for="">Sub-Category</label>
                                <input type="text" name="sub_category" class="form-control" require>
                            </div>
                            <div class="form-group">
                                <label for="">Publisher ID</label>
                                <input type="text" name="publisher_id" class="form-control" require>
                            </div>
                            <div class="form-group">
                                <label for="">Book Location</label>
                                <!-- <input type="text" name="b_location" class="form-control" require> -->
                                <select name="book_location" class="form-control" id="">
                                    <option value="">-Select Book Location-</option>
                                    <option value="DDC Center">DDC Center</option>
                                    <option value="Matikata">Matikata</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="">Book Shelf</label>
                                <input type="text" name="b_shelf" class="form-control" require>
                            </div>
                            <br>
                            <button class="btn btn-primary" name="add_book">Add Book</button>
                        </form>
                    </div>

                    <div class="col-md-3"></div>

                </div>

            </div>

        </div>
        <br><br><br><br><br><br><br>
        <footer>
            <div class="foot">
                <a href="#">
                    <h6>Copyright By LBMS</h6>
                </a>
            </div>
        </footer>


        <script src="bootstrap-5.0.2-dist/js/bootstrap.min.js"></script>
</body>

</html>