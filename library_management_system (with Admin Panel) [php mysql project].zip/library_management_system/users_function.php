<?php
function get_user_issue_book_count(){
    // database connection
    $connect = mysqli_connect('localhost','root','','lbms');
    if($connect){
        //echo("<script>alert('Connection Success')</script>");
    }else{
        echo("<script>alert('Connection Failed')</script>");
    }
    $user_issued_book_count = 0;
    $query = "select count(*) as user_issued_book_count from issued_books where 
    issued_for = $_SESSION[issued_for]";
    $query_run = mysqli_query($connect,$query);
    while($row = mysqli_fetch_array($query_run)){
        $user_issued_book_count = $row['user_issued_book_count'];
    }
    return($user_issued_book_count);
}

?>