<?php

    // Database Connection with mysql database
    $connect = mysqli_connect("localhost", "root", "", "lbms");

    $pub_id = $_GET['pn'];

    //For Show Data in Delete page input field
    $delete = "DELETE FROM publishers WHERE pub_id = $pub_id";
    $query = mysqli_query($connect, $delete);
    
    if($query){
        header("location:manage_publisher.php");
    } else{
        echo "<script>alert('Data Delete Fail')</script>";
    }

?>