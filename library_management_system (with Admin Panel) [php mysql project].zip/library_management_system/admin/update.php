<?php

session_start();

// database connection
$connect = mysqli_connect('localhost','root','','lbms');

if($connect){
    //echo("<script>alert('Connection Success')</script>");
}else{
    echo("<script>alert('Connection Failed')</script>");
}

$query = "update admins set name='$_POST[name]',email='$_POST[email]',dept='$_POST[dept]'";
?>
<script>
alert("Updated successfully...");
window.location.href = "admin_dashboard.php";
</script>