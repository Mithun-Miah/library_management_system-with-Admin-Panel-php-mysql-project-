<?php
// For Store data
session_start();

// Database Connection code Start
$servername = "localhost";
$username = "root";
$password = "";
$db_name = "lbms";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $db_name);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
echo "Connected successfully";
// Database Connection code End

// Database table and column name selection code
if(isset($_POST['submit'])){
    // html email and password field selection code
    $email = $_POST['email'];
    $oldpass = $_POST['oldpass'];
    $newpass = $_POST['newpass'];
    $confnewpass = $_POST['confnewpass'];
	
	if($newpass != $confnewpass){
		echo "<script>alert('New Password And Confirm Password Not Match!')</script>"; 
	}else{
		$query = mysqli_query($conn, "SELECT email,password from register_users where email = '$email' 
    AND password = '$oldpass' ");

    $num = mysqli_fetch_array($query);

    if($num>0){
        $con = mysqli_query($conn, "UPDATE register_users set password = '$newpass' where email = '$email' ");
   
        echo "<script>alert('Password change success')</script>";
    }else{
        echo "<script>alert('Current Password does not match')</script>";
    }
	
	}
    
}

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap-5.0.2-dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="userMainWindow.css">
    <title>Change Password</title>

    <style>
    h1 {
        background-color: blue;
        color: #fff;
        padding: 10px;
        margin: 10px;
        text-align: center;
    }

    form {
        width: 600px;
        border: 2px solid red;
        padding: 10px;
        margin: auto;
    }

    form input {
        width: 95%;
        padding: 20px;
        border-radius: 10px;
        font-size: 18px;
    }

    #submitBtn {
        cursor: pointer;
        font-size: 20px;
        font-weight: 700;
        transition: 0.3s;
    }

    #submitBtn:hover {
        background-color: #000;
        color: #fff;
    }
    </style>
</head>

<body>

    <div class="container-fluid">
        <nav class="navbar navbar-expand-lg navbar-warning bg-secondary">
            <div class="container-fluid">
                <a class="navbar-brand" href="userMainWindow.php"><img src="icons_library_app/library_logo.jpg"
                        alt="logo"></a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                    data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                    aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        <li class="nav-item">
                            <a class="nav-link" href="userMainWindow.php"><img style="width:40px;"
                                    src="icons_library_app/home-page.png" alt="home-icon"></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="logout.php"><img style="width:40px;"
                                    src="icons_library_app/logout_icon.jpg" alt="logout-icon"></a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
        <div class="title-slide">
            <marquee behavior="" direction="">Library Book Management System DDCL</marquee>
        </div>

        <div class="middle-section" style="margin:auto;display:block;">

            <form action="" method="POST" style="width:500px;margin:auto;">
                <h3 style="text-align:center; color:blue; font-weight:700;">Change Password</h3>
                <h5 style="text-align:center;"><img style="width:200px;" src="icons_library_app/user_icon.png"
                        alt="user-icon"></h5>
                <!-- <div class="form-group">
                    <label for="" style="text-shadow:none;color:black;font-size:1.3rem;font-weight:500;">Name</label>
                    <input type="text" name="name" class="form-control" value="<?php echo $name; ?>">
                </div>
                <div class=" form-group">
                    <label for="" style="text-shadow:none;color:black;font-size:1.3rem;font-weight:500;">Department
                        Name</label>
                    <input type="text" name="dept" class="form-control" value="<?php echo $dept_name; ?>">
                </div>
                <div class="form-group">
                    <label for="" style="text-shadow:none;color:black;font-size:1.3rem;font-weight:500;">Employee
                        Id</label>
                    <input type="text" name="em_id" class="form-control" value="<?php echo $em_id; ?>">
                </div>
                <div class="form-group">
                    <label for="" style="text-shadow:none;color:black;font-size:1.3rem;font-weight:500;">Email</label>
                    <input type="email" name="email" class="form-control" value="<?php echo $email; ?>">
                </div> -->

                <input type="email" name="email" placeholder="Enter New Email">
                <br><br>
                <input type="password" name="oldpass" placeholder="Enter Old Password">
                <br><br>
                <input type="password" name="newpass" placeholder="Enter New Password">
                <br><br>
                <input type="password" name="confnewpass" placeholder="Enter New Password Again">
                <br><br>
                <input type="submit" name="submit" id="submitBtn" value="Change Password">
                <br>

                <!-- <button class="btn btn-primary" type="submit" name="update">Update</button> -->
                <a href="userMainWindow.php" style="text-decoration:none;">Back Dashboard</a>
            </form>

        </div>

    </div>

    <footer>
        <div class="foot">
            <a href="#">
                <h6>Copyright By LBMS</h6>
            </a>
        </div>
    </footer>

    </div>


    <script src="bootstrap-5.0.2-dist/js/bootstrap.min.js"></script>
</body>

</html>