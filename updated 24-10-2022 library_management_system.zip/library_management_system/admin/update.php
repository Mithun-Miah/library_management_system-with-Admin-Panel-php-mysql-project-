<?php
// For Store data
session_start();

// $msg=$name=$em_id=$email= "";

$connect = mysqli_connect('localhost', 'root', '', 'library_management');

if($connect){
    //echo "<script>alert('DB Connection Success')</script>";
}else{
    echo "<script>alert('DB Connection Failed')</script>";
}

$query = "UPDATE admins SET name='$_POST[name]', email='$_POST[email]'";

$query_run = mysqli_query($connect,$query);

?>

<script>
    alert("Updated Successful");
    window.location.href = "edit_profile.php";
</script>