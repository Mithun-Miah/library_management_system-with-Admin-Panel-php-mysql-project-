<?php
session_start();
require('functions.php');

// database connection
$connect = mysqli_connect('localhost','root','','lbms');

if($connect){
    //echo("<script>alert('Connection Success')</script>");
}else{
    echo("<script>alert('Connection Failed')</script>");
}

$msg=$name=$em_id="";

// For Secure URL / do not permission enter by url type
if($_SESSION['name'] == true){
    // after login fetch email address and password display from database into this page
    $msg = "$_SESSION[name]";
    $msg2 = "Your Employee ID : $_SESSION[em_id]";
    //echo("<h1>Your Email Id : $_SESSION[email]</h1>");
    //echo("<h1>Your Name : $_SESSION[first_name]</h1>");
} else{
    header('Location: index.php');
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../bootstrap-5.0.2-dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../userMainWindow.css">
    <title>Books Item</title>
</head>

<body>

    <div class="container-fluid">
        <nav class="navbar navbar-expand-lg navbar-warning bg-secondary">
            <div class="container-fluid">
                <a class="navbar-brand" href="admin_dashboard.php"><img src="../icons_library_app/library_logo.jpg"
                        alt="logo"></a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                    data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                    aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        <li class="nav-item">
                            <a class="nav-link" href="admin_dashboard.php"><img style="width:40px;"
                                    src="../icons_library_app/arrow.png" alt="arrow-icon"></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="admin_dashboard.php"><img style="width:40px;"
                                    src="../icons_library_app/home-page.png" alt="home-icon"></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="logout.php"><img style="width:40px;"
                                    src="../icons_library_app/logout_icon.jpg" alt="logout-icon"></a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
        <div class="title-slide">
            <marquee behavior="" direction="">Library Book Management System DDCL</marquee>
        </div>

        <div class="middle-section">

            <div class="user-information">

                <div class="row w-100" style="display:flex;flex-wrap:nowrap;margin-top:25px;">
                    <div class="col-md-2"></div>
                    <div class="col-md-4" style="text-align:center;border:1px solid red;padding:20px;">

                        <a href="add_book.php" style="text-decoration:none;">
                            <img style=" width:130px;" src="../icons_library_app/book.jpg" alt="book-icon">
                            <h5>Add New Book</h5>
                        </a>
                    </div>

                    <div class="col-md-4" style="text-align:center;border:1px solid red;padding:20px;margin:0px 10px;">
                        <a href="manage_book.php" style="text-decoration:none;">
                            <img style=" width:130px;" src="../icons_library_app/book_manage.jpg" alt="info-icon">
                            <h5>Manage New Book</h5>
                        </a>

                    </div>
                    <div class="col-md-2"></div>

                </div>

            </div>

        </div>
        <br><br><br><br><br><br><br>
        <footer>
            <div class="foot">
                <a href="#">
                    <h6>Copyright By LBMS</h6>
                </a>
            </div>
        </footer>


        <script src="bootstrap-5.0.2-dist/js/bootstrap.min.js"></script>
</body>

</html>