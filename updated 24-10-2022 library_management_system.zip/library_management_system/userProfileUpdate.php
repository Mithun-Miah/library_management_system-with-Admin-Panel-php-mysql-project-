<?php
// For Store data
session_start();

$msg=$name=$em_id=$email="";

$connect = mysqli_connect('localhost', 'root', '', 'library_management');

if($connect){
    //echo "<script>alert('DB Connection Success')</script>";
}else{
    echo "<script>alert('DB Connection Failed')</script>";
}

// For Secure URL / do not permission enter by url type
if($_SESSION['name'] == true){
    // after login fetch email address and password display from database into this page
    $msg = "$_SESSION[name]";
    $msg2 = "$_SESSION[em_id]";
    $msg3 = "$_SESSION[email]";

} else{
    header('Location: index.php');
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap-5.0.2-dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="passwordChange.css">
    <title>USER | UPDATE PROFILE</title>
</head>
<body>
<div class="container-fluid">

<nav class="navbar navbar-expand-lg navbar-warning bg-secondary">
                <div class="container-fluid">
                    <a class="navbar-brand" href="#"><img src="icons_library_app/library_logo.jpg" alt="logo"></a>
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="user_main_window.php"><img style="width:30px;" src="icons_library_app/home-page.png" alt="home-icon"></a>
                        </li>
                        <li class="nav-item">
                        <a class="nav-link" href="logout.php"><img style="width:30px;" src="icons_library_app/logout_icon.jpg" alt="logout-icon"></a>
                        </li>
                    </ul>

                    </div>
</nav>

        <div class="title-slide">
            <marquee behavior="" direction="">Library Book Management System DDCL</marquee>
        </div>
<br></br>
<div class="pass-changeForm" style="width:600px;margin:auto;border-radius:20px;box-shadow:2px 4px 6px black;border:2px solid green;padding:20px;text-align:center;">

<form action="userInfoUpdate.php" method="POST">

    <h3 style="color:white;background-color:#10bccc;padding:8px;">Update Your Profile</h3>
    <input type="employee_name" name="name" value="<?php echo $msg; ?>" style="width:80%;border:none;padding:8px;border-radius:8px;">
    <br><br>
    <input type="employee_id" name="em_id" value="<?php echo $msg2; ?>" style="width:80%;border:none;padding:8px;border-radius:8px;">
    <br><br>
    <input type="email" name="email" value="<?php echo $msg3; ?>" style="width:80%;border:none;padding:8px;border-radius:8px;">
    <br><br>
    
    <input type="submit" name="edit_Btn" id="edit_Btn" value="Update" style="width:80%;box-shadow:2px 4px 6px black;border:none;padding:8px;border-radius:8px;background-color:#258c06;color:white;font-size:1.3rem;font-weight:600;">

</form>

</div>
<br></br><br></br>
    <footer>
        <div class="foot">
            <a href="#"><h6>Copyright By LBMS</h6></a>
        </div>
    </footer>
</div>

<script src="bootstrap-5.0.2-dist/js/bootstrap.min.js"></script>
</body>
</html>