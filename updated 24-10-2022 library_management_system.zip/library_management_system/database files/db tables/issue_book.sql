-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 24, 2022 at 12:13 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `library_management`
--

-- --------------------------------------------------------

--
-- Table structure for table `issue_book`
--

CREATE TABLE `issue_book` (
  `id` int(11) NOT NULL,
  `book_id` varchar(100) NOT NULL,
  `b_title` varchar(1000) NOT NULL,
  `author_name` varchar(100) NOT NULL,
  `publisher_name` varchar(100) NOT NULL,
  `category` varchar(100) NOT NULL,
  `issued_by` varchar(50) NOT NULL,
  `issued_for` varchar(50) NOT NULL,
  `issue_date` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `issue_book`
--

INSERT INTO `issue_book` (`id`, `book_id`, `b_title`, `author_name`, `publisher_name`, `category`, `issued_by`, `issued_for`, `issue_date`) VALUES
(1, 'A-01756', 'GREAT AMERICAN POST OFFICES', 'JAMES H. BRUNS', 'JOHN WILEY & SONS', 'Architecture', 'Mithun', 'Hannan', ''),
(2, 'A-07204', 'A POLICY ON ROADSIDE ADVERTISEMENTS (FIRST REVISION) (IRC : 46-1972)', 'IRC', 'IRC', 'Engineering', 'Mithun', 'Hannan', 'issue_date'),
(3, 'A-16243', 'GIS APPLICATIONS FOR WATER, WASTEWATER, AND STORMWATER SYSTEMS', 'UM SHAMSI', 'CRC PRESS', 'Engineering', 'Raihan', 'Mithun', '06/04/2022'),
(4, 'A-01471', 'AN INTRODUCTION TO MECHANICAL VIBRATIONS', 'ROBERT F. STEIDEL', 'JOHN WILEY & SONS', 'Engineering', 'Nasir', 'Hannan', '07/04/2022');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `issue_book`
--
ALTER TABLE `issue_book`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `issue_book`
--
ALTER TABLE `issue_book`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
